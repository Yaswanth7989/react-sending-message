import './App.css';
import MessageList from './components/MessageList';

function App() {
  return (
    <div>
        <MessageList/>
    </div>
  );
}

export default App;
